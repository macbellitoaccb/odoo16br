* Formatação da Inscrição Estadual de acordo com cada UF.
