Este módulo depende dos pacotes Python:

* `erpbrasil.base <https://github.com/erpbrasil/erpbrasil.base>`_
* num2words
* phonenumbers
* email_validator
