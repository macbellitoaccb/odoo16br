* `Akretion <https://www.akretion.com/pt-BR>`_:

  * Renato Lima <renato.lima@akretion.com.br>
  * Raphaël Valyi <raphael.valyi@akretion.com.br>
  * Magno Costa <magno.costa@akretion.com.br>

* `KMEE <https://www.kmee.com.br>`_:

  * Luis Felipe Mileo <mileo@kmee.com.br>
  * Luis Otavio Malta Conceição <luis.malta@kmee.com.br>

* `Escodoo <https://www.escodoo.com.br>`_:

  * Marcel Savegnago <marcel.savegnago@escodoo.com.br>

* `Engenere <https://engenere.one>`_:

  * Antônio S. Pereira Neto <neto@engenere.one>
  * Felipe Motter Pereira <felipe@engenere.one>
